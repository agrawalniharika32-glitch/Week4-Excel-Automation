Attribute VB_Name = "SalesAutomation"
Option Explicit

' Week 4 - YuvaIntern: Automation and Macro Development in Excel
' Assumptions:
'   1. Source worksheet is named "Sales Data".
'   2. Row 1 contains headers: Order ID, Date, Region, Product, Units, Revenue.
'   3. Data begins in row 2; Revenue is in column F and Region is in column C.
'   4. The macros work on a copy of the workbook first. Adjust columns if your layout differs.

Public Sub CleanSalesData()
    Dim ws As Worksheet
    Dim lastRow As Long, lastCol As Long
    Dim dataRange As Range
    Dim revenueCol As Long, dateCol As Long
    Dim headerCell As Range
    Dim c As Long

    On Error GoTo ErrHandler
    Set ws = ThisWorkbook.Worksheets("Sales Data")

    If Application.WorksheetFunction.CountA(ws.Cells) = 0 Then
        MsgBox "The Sales Data sheet is empty.", vbExclamation
        Exit Sub
    End If

    lastRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    lastCol = ws.Cells(1, ws.Columns.Count).End(xlToLeft).Column

    If lastRow < 2 Or lastCol < 1 Then
        MsgBox "No data rows were found below the header.", vbExclamation
        Exit Sub
    End If

    Set dataRange = ws.Range(ws.Cells(1, 1), ws.Cells(lastRow, lastCol))
    dataRange.Rows(1).Font.Bold = True
    dataRange.Rows(1).Interior.Color = RGB(221, 235, 247)

    ' Trim leading/trailing spaces in text cells; does not change numeric/date values.
    For Each headerCell In dataRange.Rows(1).Cells
        If LCase(Trim(CStr(headerCell.Value))) = "date" Then dateCol = headerCell.Column
        If LCase(Trim(CStr(headerCell.Value))) = "revenue" Then revenueCol = headerCell.Column
    Next headerCell

    For c = 1 To lastCol
        If VarType(ws.Cells(1, c).Value) = vbString Then
            ws.Cells(1, c).Value = Trim(ws.Cells(1, c).Value)
        End If
    Next c

    Dim r As Long
    For r = 2 To lastRow
        For c = 1 To lastCol
            If VarType(ws.Cells(r, c).Value) = vbString Then
                ws.Cells(r, c).Value = Trim(ws.Cells(r, c).Value)
            End If
        Next c
    Next r

    If dateCol > 0 Then ws.Columns(dateCol).NumberFormat = "dd-mmm-yyyy"
    If revenueCol > 0 Then ws.Columns(revenueCol).NumberFormat = "₹#,##0.00"

    dataRange.Columns.AutoFit
    MsgBox "Basic cleaning and formatting completed. Please review the data before analysis.", vbInformation
    Exit Sub

ErrHandler:
    MsgBox "CleanSalesData could not finish: " & Err.Description, vbCritical
End Sub

Public Sub BuildRegionSummary()
    Dim sourceWs As Worksheet, summaryWs As Worksheet
    Dim lastRow As Long, lastCol As Long, regionCol As Long, revenueCol As Long
    Dim r As Long, outRow As Long
    Dim regionName As String
    Dim revenueValue As Double
    Dim totals As Object
    Dim key As Variant
    Dim header As Range

    On Error GoTo ErrHandler
    Set sourceWs = ThisWorkbook.Worksheets("Sales Data")
    lastRow = sourceWs.Cells(sourceWs.Rows.Count, 1).End(xlUp).Row
    lastCol = sourceWs.Cells(1, sourceWs.Columns.Count).End(xlToLeft).Column

    For Each header In sourceWs.Range(sourceWs.Cells(1, 1), sourceWs.Cells(1, lastCol))
        Select Case LCase(Trim(CStr(header.Value)))
            Case "region": regionCol = header.Column
            Case "revenue", "sales": revenueCol = header.Column
        End Select
    Next header

    If regionCol = 0 Or revenueCol = 0 Then
        MsgBox "Required headers 'Region' and 'Revenue' (or 'Sales') were not found.", vbExclamation
        Exit Sub
    End If
    If lastRow < 2 Then
        MsgBox "There are no sales records to summarize.", vbExclamation
        Exit Sub
    End If

    Set totals = CreateObject("Scripting.Dictionary")
    For r = 2 To lastRow
        regionName = Trim(CStr(sourceWs.Cells(r, regionCol).Value))
        If Len(regionName) > 0 And IsNumeric(sourceWs.Cells(r, revenueCol).Value) Then
            revenueValue = CDbl(sourceWs.Cells(r, revenueCol).Value)
            If totals.Exists(regionName) Then
                totals(regionName) = totals(regionName) + revenueValue
            Else
                totals.Add regionName, revenueValue
            End If
        End If
    Next r

    On Error Resume Next
    Set summaryWs = ThisWorkbook.Worksheets("Region Summary")
    On Error GoTo ErrHandler
    If summaryWs Is Nothing Then
        Set summaryWs = ThisWorkbook.Worksheets.Add(After:=sourceWs)
        summaryWs.Name = "Region Summary"
    Else
        summaryWs.Cells.Clear
    End If

    summaryWs.Range("A1:B1").Value = Array("Region", "Total Revenue")
    summaryWs.Range("A1:B1").Font.Bold = True
    summaryWs.Range("A1:B1").Interior.Color = RGB(221, 235, 247)

    outRow = 2
    For Each key In totals.Keys
        summaryWs.Cells(outRow, 1).Value = key
        summaryWs.Cells(outRow, 2).Value = totals(key)
        outRow = outRow + 1
    Next key

    If outRow > 2 Then
        summaryWs.Range("B2:B" & outRow - 1).NumberFormat = "₹#,##0.00"
        summaryWs.Columns("A:B").AutoFit
        summaryWs.Range("A1:B" & outRow - 1).Sort _
            Key1:=summaryWs.Range("B2"), Order1:=xlDescending, Header:=xlYes
    End If

    MsgBox "Region summary created or refreshed.", vbInformation
    Exit Sub

ErrHandler:
    MsgBox "BuildRegionSummary could not finish: " & Err.Description, vbCritical
End Sub

Public Sub RefreshAnalysis()
    Dim ws As Worksheet
    On Error GoTo ErrHandler

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationAutomatic

    ' Refresh existing PivotTables/connections if present.
    ThisWorkbook.RefreshAll

    ' Run the two repeatable preparation tasks.
    CleanSalesData
    BuildRegionSummary

    For Each ws In ThisWorkbook.Worksheets
        ws.Columns.AutoFit
    Next ws

    Application.ScreenUpdating = True
    Application.EnableEvents = True
    MsgBox "Refresh routine completed. Check the results and any external-data refresh messages.", vbInformation
    Exit Sub

ErrHandler:
    Application.ScreenUpdating = True
    Application.EnableEvents = True
    MsgBox "RefreshAnalysis stopped: " & Err.Description, vbCritical
End Sub
